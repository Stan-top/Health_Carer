# nrf52840_littlevGL 
 - https://qwert1213131.github.io/nrf52840_littlevGL/
 - 使用高速spi驱动1.54寸lcd 
 - nRF5_SDK_15.2.0_9412b96
 - ses开发环境
 - 将文件夹直接放进\examples\peripheral下面

### Todo:
- [x] st7789显示驱动
- [x] ft6336触摸驱动
- [ ] microSD卡驱动
- [ ] 按键处理
- [ ] 定时器引入
- [ ] microSD
- [ ] UI
- [ ] BLE